#pragma once

#ifndef VECTOR_H
#define VECTOR_H

#include <iostream>

template<typename T>
class vector {

private:
    const short default_capacity = 10;
    short size, capacity, i;
    T* arr;

public:
    vector() :size(0), capacity(default_capacity), arr(new T[capacity])
    {}
    vector(short amount, T value = T()) :size(amount), capacity(default_capacity), arr(new T[capacity]) {
        if (amount <= 0) throw;
        for (i = 0; i < size; ++i)
            push_back(value);
    }

    ~vector() {
        for (i = 0; i < capacity; ++i)
            (arr + i)->~T();

        delete[] arr;
    }

    class iterator {

    private: T* cur;
    public:
        iterator() :cur(nullptr) {}

        iterator(T* value) :cur(value) {}

        T& operator+ (short n) { return *(cur + n); }
        T& operator- (short n) { return *(cur - n); }
        T& operator++ () { return *(++cur); }
        T& operator-- () { return *(--cur); }
        T& operator++ (int) { return *(cur++); }
        T& operator-- (int) { return *(cur--); }
        bool operator!= (const iterator& rhs) { return cur != rhs.cur; }
        bool operator== (const iterator& rhs) { return cur == rhs.cur; }
        T& operator* () { return *cur; }
    };

    class const_iterator {
    private: T* cur;
    public:
        const_iterator() {}
        const_iterator(T* value) :cur(value) {}

        T& operator+ (short n) { return *(cur + n); }
        T& operator- (short n) { return *(cur - n); }
        T& operator++ () { return *(++cur); }
        T& operator-- () { return *(--cur); }
        bool operator!= (const const_iterator& rhs) { return cur != rhs.cur; }
        bool operator== (const const_iterator& rhs) { return cur == rhs.cur; }
        const T& operator* () { return *cur; }
    };

    class reverse_iterator {
    private: T* cur;
    public:
        reverse_iterator() {}
        reverse_iterator(T* value) :cur(value) {}
        T& operator+ (short n) { return *(cur - n); }
        T& operator- (short n) { return *(cur + n); }
        T& operator++ () { return *(--cur); }
        T& operator-- () { return *(++cur); }
        bool operator!= (const reverse_iterator& rhs) { return cur != rhs.cur; }
        bool operator== (const reverse_iterator& rhs) { return cur == rhs.cur; }
        T& operator* () { return *cur; }
    };

    void reserve(short newCapacity) {

        if (newCapacity <= capacity) return;

        T* newarr = new T[newCapacity];

        for (i = 0; i < size; ++i)
            new(newarr + i) T(arr[i]);

        try {
            for (i = 0; i < size; ++i)
                new(newarr + i) T(arr[i]);
        }
        catch (...) {
            for (short j = 1; j < i; ++j)
                (newarr + j)->~T();
            delete[] newarr;
            throw;
        }

        for (i = 0; i < size; ++i)
            (arr + i)->~T();

        delete[] arr;

        arr = newarr;
        capacity = newCapacity;
    }

    void resize(short newSize, T value) {
        if (newSize >= capacity) reserve(newSize * 2);

        for (i = size; i < newSize; ++i)
            new(arr + i) T(value);
        size = newSize;
    }

    void resize(short newSize) {
        if (newSize > size) return resize(newSize, T());
        size = newSize;
    }

    void assign(iterator First, iterator Last) {

        short newSize = 0, position_to_start = 0;

        for (; arr[position_to_start] != *First; ++position_to_start);

        for (iterator it = First; it != Last; ++it, ++newSize);

        if (newSize == 0) return clear();

        T* newarr = new T*[capacity];

        try {
            for (short j = 0, i = position_to_start; j < newSize; ++i, ++j)
                new(newarr + j) T(arr[i]);
        }
        catch (...) {
            for (short j = 0; j < i; ++j)
                (newarr + j)->~T();
            delete[] newarr;
            throw;
        }

        for (i = 0; i < size; ++i)
            (arr + i)->~T();
        delete[] arr;

        arr = newarr;
        size = newSize;

    }

    void push_back(const T value = T()) {
        if (capacity == size) reserve(2 * size);

        new(arr + size) T(value);
        ++size;
    }

    void erase(short position) {

        if (size == 0 || position >= size || position < 0)
            return;

        if (position == size - 1) return pop_back();

        T* newarr = new T[capacity - 1];

        short j = 0;

        for (i = 0; i < size; ++i)
            if (i != position) {
                new(newarr + j) T(arr[i]);
                ++j;
            }

        for (i = 0; i < size; ++i)
            (arr + i)->~T();

        delete[] arr;

        arr = newarr;

        --size;
    }

    void erase(short position, short amount) {
        if (size == 0 || amount > size || amount < 0
            || position < 0 || position >= size)
            return;

        if (!amount) return;
        if (amount == 1) return erase(position);



        T* newarr = new T[capacity - amount];

        short j = 0;
        try {
            for (i = 0; i < size; ++i) {
                if (i == position) i += amount;
                new(newarr + j) T(arr[i]);
                ++j;
            }
        }
        catch (...) {
            for (short k = 0; k < j; ++k)
                (newarr + k)->~T();
            delete[] newarr;
            throw;
        }
        for (i = 0; i < size; ++i)
            (arr + i)->~T();
        delete[] arr;

        arr = newarr;
        size -= amount;
    }

    iterator emplace_back(const T value = T()) {
        if (size == capacity) reserve(2 * size);
        return iterator(new(arr + size++)T(std::move(value)));
    }

    inline void pop_back() {

        if (size == 0)
            return;
        --size;
        (arr + size)->~T();
    }

    inline void clear() {
        for (i = 0; i < size; ++i)
            (arr + i)->~T();
        size = 0;
    }

    inline void shrink_to_fit() {
        if (capacity == size) return;
        for (i = size; i < capacity; ++i)
            (arr + i)->~T();
        capacity = size;
    }

    void insert(const short position, const T value = T()) {
        if (position < 0 || position > size)
            return;

        if (position == size) return push_back(value);
        if (size == capacity) reserve(size * 2);

        for (i = size; i >= position; --i)
            arr[i] = arr[i - 1];

        arr[position] = value;
        ++size;
    }

    void insert(iterator position, const T value = T()) {
        short int_position = 0;
        for (vector<T>::iterator it = begin(); it != position; ++it)
            ++int_position;
        insert(position, value);
    }

    iterator emplace(const short position, const T value = T()) {
        if (position < 0 || position > size)
            return;

        if (position == size) return emplace_back(std::move(value));
        if (size == capacity) reserve(size * 2);

        for (i = size; i >= position; --i)
            arr[i] = arr[i - 1];

        ++size;

        return new(arr + position)T(std::move(value));
    }

    iterator emplace(iterator position, const T value = T()) {
        short int_position = 0;
        for (vector<T>::iterator it = begin(); it != position; ++it)
            ++int_position;
        return emplace(int_position, std::move(value));
    }

    void insert(short position, short amount, const T value = T()) {
        if (position < 0 || position > size || amount < 0)
            return;

        for (amount; amount > 0; --amount, ++position)
            insert(position, value);
    }

    void insert(iterator position, short amount, const T value = T()) {
        short int_position = 0;
        for (vector<T>::iterator it = begin(); it != position; ++it)
            ++int_position;
        if (int_position < 0 || int_position > size || amount < 0)
            return;

        for (amount; amount > 0; --amount, ++int_position)
            insert(int_position, value);
    }

    iterator emplace(short position, short amount, const T value = T()) {
        if (position < 0 || position > size || amount < 0)
            return;

        for (amount; amount > 0; --amount, ++position)
            emplace(position, std::move(value));
        return arr + position;
    }

    iterator emplace(iterator position, short amount, const T value = T()) {
        short int_position = 0;
        for (vector<T>::iterator it = begin(); it != position; ++it)
            ++int_position;
        if (int_position < 0 || int_position > size || amount < 0)
            return;

        for (amount; amount > 0; --amount, ++int_position)
            emplace(int_position, value);
        return arr + int_position;
    }

    T& operator= (const vector& rhs) {
        T* newarr = new T[rhs.Capacity()];
        try {
            for (i = 0; i < rhs.Size(); ++i) {
                new(newarr + i) T(rhs.arr[i]);
            }
        }
        catch (...) {
            for (short j = 0; j < i; ++j)
                (newarr + j)->~T();
            delete[] newarr;
            throw;
        }
        for (i = 0; i < size; ++i)
            (arr + i)->~T();
        delete[] arr;
        arr = newarr;
        size = rhs.Size();
    }

    void swap(vector& rhs) {

        vector<T> lhs;
        for (i = 0; i < size; ++i)
            lhs.push_back(arr[i]);

        vector<T> temp;
        for (i = 0; i < rhs.Size(); ++i)
            temp.push_back(rhs.arr[i]);

        rhs = lhs;
        lhs = temp;

        T* newarr = new T[lhs.Capacity()];
        try {
            for (i = 0; i < lhs.Size(); ++i) {
                new(newarr + i) T(lhs[i]);
            }
        }
        catch (...) {
            for (short j = 0; j < i; ++j)
                (newarr + j)->~T();
            delete[] newarr;
            throw;
        }
        for (i = 0; i < size; ++i)
            (arr + i)->~T();
        delete[] arr;

        arr = newarr;
        size = lhs.Size();
    }

    void sort() {
        int j, step;
        T tmp;
        for (step = size / 2; step > 0; step /= 2)
            for (i = step; i < size; i++) {
                tmp = arr[i];
                for (j = i; j >= step; j -= step)
                    if (tmp < arr[j - step]) arr[j] = arr[j - step];
                    else break;

                arr[j] = tmp;
            }
    }

    bool operator == (const vector& rhs) const {
        if (size != rhs.size) return false;
        for (int j = 0; j < size; ++j)
            if (arr[j] != rhs[j]) return false;
        return true;
    }

    bool operator != (const vector& rhs) const {
        return !(*this == rhs);
    }

    inline bool empty() {
        return !size; //return size == 0
    }

    inline const unsigned long long& max_size() const {
        return pow(2, 64) / sizeof(T) - 1;
    }

    inline const short& Size() const {
        return size;
    }

    inline const short& Capacity() const {
        return capacity;
    }

    inline T& front() {
        if (size == 0)
            return T();
        return arr[0];
    }

    inline T& back() {
        if (size == 0)
            return T();
        return arr[size - 1];
    }

    inline T& operator[] (short index) {

        return arr[index];
    }

    inline T& at(short index) {

        if (index >= size || index < 0) {

            T value = T();
            return value;
        }
        return arr[index];
    }

    inline iterator begin() {
        return iterator(arr);
    }

    inline const const_iterator begin() const {
        return const_iterator(arr);
    }

    inline const const_iterator cbegin() const {
        return const_iterator(arr);
    }

    inline const reverse_iterator crbegin() const {
        return reverse_iterator(arr + size - 1);
    }

    inline iterator end() {
        return iterator(arr + size);
    }

    inline const const_iterator end() const {
        return const_iterator(arr + size);
    }

    inline const const_iterator cend() const {
        return const_iterator(arr + size);
    }

    inline const reverse_iterator crend() const {
        return reverse_iterator(arr);
    }

    bool isEmpty() const {
        return !size;
    }

    const unsigned Size() {
        return size;
    }

};

struct _Vb_val {

private:
    _int8* value_ptr;
    _int8 position;

public:

    _Vb_val() = default;

    _Vb_val(_int8* ptr, _int8 pos) : value_ptr(ptr), position(pos) {}

    _Vb_val& operator= (bool rhs) {
        rhs ? *value_ptr |= ((_int8)1 << position) :
            *value_ptr &= ~((_int8)1 << position);
        return *this;
    }

    operator bool() const {
        return *value_ptr & ((_int8)1 << position);
    }
};

template<>
class vector<bool> : public _Vb_val {

private:

    const size_t default_capacity = 15;

    size_t size = 0, capacity = default_capacity;

    _int8* arr = new _int8[capacity];


public:

    vector() = default;


    vector(short amount, bool value) :size(amount), capacity(default_capacity), arr(new _int8[capacity]) {

        if (amount <= 0) throw;

        for (size_t i = 0; i < size; ++i)
            push_back(value);
    }

    ~vector() {

        //delete[] arr;
    }

    _Vb_val operator[](size_t i) {

        _int8 position = i % 8;

        _int8* ptr = arr + i / 8;

        return _Vb_val(ptr, position);
    }

    void reserve(short newCapacity) {

        if (newCapacity <= capacity) return;

        _int8* newarr = new _int8[newCapacity];

        size_t i;

        for (i = 0; i < size; ++i)
            newarr[i] = _int8(arr[i]);

        try {
            for (i = 0; i < size; ++i)
                *(newarr + i) = _int8(arr[i]);
        }
        catch (...) {
            for (short j = 1; j < i; ++j)
                delete (newarr + j);

            delete[] newarr;
            throw;
        }

        for (i = 0; i < size; ++i)
            delete (arr + i);

        delete[] arr;

        arr = newarr;
        capacity = newCapacity;
    }

    void push_back(bool value) {

        if (size == capacity)
            reserve(capacity * 2);

        _int8 position = size % 8;

        _int8* ptr = arr + size / 8;

        if (value)
            *arr |= 1 << position;
        else
            *arr &= ~(1 << position);

        ++size;
    }

    const size_t Size() {
        return size;
    }

    const size_t Capacity() {
        return capacity;
    }
};
#endif // VECTOR_H
